HSEM Bolivia Dengue – Outputs
- param_summary.csv: posterior summaries for Intercept, betas (latent factors), phi.
- loadings_*.csv: posterior mean loadings per latent factor (marker fixed at 1).
- posterior_predictive_series.csv: standardized observed vs posterior mean.
- trace_structural_params.png: MCMC trace of structural parameters.
- loadings_*.png: bar plots of factor loadings.
- ppc_timeseries_*.png: observed vs predicted series for top regions.
- path_diagram.png: schematic path diagram.
